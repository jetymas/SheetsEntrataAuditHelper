export { default } from "./A.mjs";
export * from "./A.mjs";
